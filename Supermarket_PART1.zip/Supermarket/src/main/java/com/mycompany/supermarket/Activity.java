package com.mycompany.supermarket;

/**
 *
 * @author Stela
 */
public class Activity {

    private int activityId;
    private String activityName;
    private String productItem;
    private int activityQuantity;
    private String activityDate;

    public Activity(int activityId, String activityName, String productItem, int activityQuantity, String activityDate) {
        this.activityId = activityId;
        this.activityName = activityName;
        this.productItem = productItem;
        this.activityQuantity = activityQuantity;
        this.activityDate = activityDate;
    }

    public void setActivityId(int newActivityId) {
        activityId = newActivityId;
    }

    public int getActivityId() {
        return activityId;
    }

    public void setActivityName(String newActivityName) {
        activityName = newActivityName;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setProductItem(String newProductItem) {
        productItem = newProductItem;
    }

    public String getProductItem() {
        return productItem;
    }

    public void setActivityQuantity(int newActivityQuantity) {
        activityQuantity = newActivityQuantity;
    }

    public int getActivityQuantity() {
        return activityQuantity;
    }

    public void setActivityDate(String newActivityDate) {
        activityDate = newActivityDate;
    }

    public String getActivityDate() {
        return activityDate;
    }

    public String displayActivity() {
        return "Activity ID: " + activityId + "\n"
                + "Name: " + activityName + "\n"
                + "Product: " + productItem + "\n"
                + "Date: " + activityDate + "\n"
                + "Quantity: " + activityQuantity + "\n";
    }
}
