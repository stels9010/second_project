package com.mycompany.supermarket;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;

/**
 *
 * @author Stela
 */
public class MyFrame extends javax.swing.JFrame {

    private ArrayList<Product> productList = new ArrayList<>();
    private ArrayList<Activity> activities = new ArrayList<>();
    private Map<String, List<Activity>> productActivityList = new HashMap<>();

    /**
     * Creates new form MyFrame
     */
    public MyFrame() {
        initComponents();
    }

    // This method maps a product to its associated activity by updating the productActivityList
    public void mapProductToActivity(String productName, Activity activity) {
        // Using computeIfAbsent to handle the creation of a new ArrayList if the product is not present
        productActivityList.computeIfAbsent(productName, k -> new ArrayList<>()).add(activity);
    }

    // This method retrieves the text from the productIdTextF text field and parsing it into Integer
    public int getIdProduct() {
        int getIdProduct = 0;
        try {
            getIdProduct = Integer.parseInt(productIdTextF.getText());
            // Check if the ID is not negative
            if (getIdProduct < 0) {
                JOptionPane.showMessageDialog(this, "Please enter a positive number!");
                getIdProduct = 0;
            }
        } catch (NumberFormatException exception) {
            JOptionPane.showMessageDialog(this, "Please enter a number!");
        }
        return getIdProduct;
    }

    // This method retrieves the text from the productNameTextF text field
    public String getName() {
        return productNameTextF.getText();
    }

    // This method retrieves the text from the productCategoryBox combo box , and cast it to String
    public String getCategory() {
        return (String) productCategoryBox.getSelectedItem();
    }

    // This method retrieves the text from the productDateTextF text field  
    public String getDateProduct() {
        return productDateTextF.getText();
    }

    // This method retrieves the text from the productQuantityTextF text field and parsing it into Integer
    public int getQuantityProduct() {
        int getQuantityProduct = 0;
        try {
            getQuantityProduct = Integer.parseInt(productQuantityTextF.getText());

            // Check if the quantity is not negative
            if (getQuantityProduct < 0) {
                JOptionPane.showMessageDialog(this, "Please enter a positive quantity number!");
                getQuantityProduct = 0;
            }
        } catch (NumberFormatException exception) {
            JOptionPane.showMessageDialog(this, "Please enter a quantity!");
        }
        return getQuantityProduct;
    }

    // This method retrieves the text from the categoryTextField text field
    public String getSearchCategory() {
        return categoryTextField.getText();
    }


    // This method retrieves the text from the deleteTextF text field and parsing it into Integer
    public int getDeleteProductID() {
        int displayId = 0;
        try {
            displayId = Integer.parseInt(deleteTextF.getText());
            // Check if the ID is not negative
            if (displayId < 0) {
                JOptionPane.showMessageDialog(this, "Please enter a positive number!");
                displayId = 0;
            }
        } catch (NumberFormatException exception) {
            JOptionPane.showMessageDialog(this, "Please enter a number!");
        }
        return displayId;
    }

    // This method retrieves the text from the activityIdTextF text field and parsing it into Integer
    public int getIdActivity() {
        int getIdActivity = 0;
        try {
            getIdActivity = Integer.parseInt(activityIdTextF.getText());
            // Check if the ID is not negative
            if (getIdActivity < 0) {
                JOptionPane.showMessageDialog(this, "Please enter a positive number!");
                getIdActivity = 0;
            }
        } catch (NumberFormatException exception) {
            JOptionPane.showMessageDialog(this, "Please enter a number!");
        }
        return getIdActivity;
    }

    // This method retrieves the text from the activityBox combo box ,and cast it to a String
    public String getActivityName() {
        return (String) activityBox.getSelectedItem();
    }

    // This method retrieves the text from the activityDateTextF text field 
    public String getDateActivity() {
        return activityDateTextF.getText();
    }

    // This method retrieves the text from the activityQuantityIdTextF text field and parsing it into Integer
    public int getQuantityActivity() {
        int getQuantityActivity = 0;
        try {
            getQuantityActivity = Integer.parseInt(activityQuantityTextF.getText());

            // Check if the quantity is not negative
            if (getQuantityActivity < 0) {
                JOptionPane.showMessageDialog(this, "Please enter a positive quantity number!");
                getQuantityActivity = 0;
            }
        } catch (NumberFormatException exception) {
            JOptionPane.showMessageDialog(this, "Please enter a quantity!");
        }
        return getQuantityActivity;
    }

    // This method retrieves the text from the itemBox combo box , and cast it to a String
    public String getProductItem() {
        return (String) itemBox.getSelectedItem();
    }

    // This method retrieves the text from the activityTextArea text area and its taking 1 parameter called activityInfo
    public void updateActivityInfoTextArea(String activityInfo) {
        activityTextArea.setText(activityInfo);
    }
    
    // This method retrieves the text from the productTextArea text area and its taking 1 parameter called productInfo
    public void updateProductInfoTextArea(String productInfo) {
        productTextArea.setText(productInfo);
    }

    // This method add the product to the product list
    public void addProduct(Product product) {
        productList.add(product);
        JOptionPane.showMessageDialog(this, "The product is added");

        getProductItems(); // Adding the items from the list to the activity itemBox 
    }

    // This method delete the product from the product list
    public void deleteProduct() {
        int deleteID = getDeleteProductID();
        Product removeProduct = null;

        // Iterating through the list to find the product 
        for (Product a : productList) {
            if (a.getProductId() == deleteID) {
                removeProduct = a;
                break;
            }
        }
        // If the product is found, it is removed from the list
        if (removeProduct != null) {
            productList.remove(removeProduct);
            JOptionPane.showMessageDialog(this, "Product with ID " + deleteID + " has been deleted.");
        } else {
            JOptionPane.showMessageDialog(this, "Product with ID " + deleteID + " not found.");
        }

        getProductItems(); // After we delete the product, the item name will be delete as well
    }
    
    // This method get the product items from the product list and adds them to the item box where we can choose from 
    // when we need to add the activity for the particular item
    public void getProductItems() {
        itemBox.removeAllItems(); // Clear the existing items in the itemBox
        for (Product item : productList) {
            itemBox.addItem(item.getProductName());
        }
    }

    // This method displays the product information
    public void displayProductInfo() {
        StringBuilder productInfo = new StringBuilder();

        // Iterating through the list to gather the information
        for (Product a : productList) {
            productInfo.append(a.displayProduct()).append("\n");
        }
        this.updateProductInfoTextArea(productInfo.toString());
    }

    // This method displays the product by its category and sort it by quantity
    public void displayByCategory() {
        String category = getSearchCategory(); // Get the category from user input
        boolean found = false;  // Variable to track if the product is found
        StringBuilder productInfo = new StringBuilder();

        // Retrieve two products for comparison
        productList.sort((product1, product2) -> {
            // Check if both products are in the specified category
            if (product1.getCategoryProduct().equals(category) && product2.getCategoryProduct().equals(category)) {
                // Compare the two products by quantity and return the result
                return Integer.compare(product1.getProductQuantity(), product2.getProductQuantity());
            } else {
                return 0;
            }
        });

        // Iterate through the sorted products
        for (Product product : productList) {
            if (product.getCategoryProduct().equals(category)) {
                productInfo.append(product.displayProduct()).append("\n");
                found = true;
            }
        }

        // Check if any products in the specified category were found
        if (found) {
            updateProductInfoTextArea(productInfo.toString());
        } else {
            JOptionPane.showMessageDialog(this, "No products found in the category: " + category);
        }
    }

    
    //This method add stock to the list
    public void addToStock(Activity newActivity) {
        String productName = getProductItem();

        // Add the activity to the list
        activities.add(newActivity);
        JOptionPane.showMessageDialog(this, "Added to the stock!");

        // Map the product to the activity
        mapProductToActivity(productName, newActivity);

        updateProductQuantity(); // Update the Product Quantity
    }

    //This method remove stock from the list
    public void removeFromStock(Activity newActivity) {
        String productName = getProductItem();

        // Add the activity to the list
        activities.add(newActivity);
        JOptionPane.showMessageDialog(this, "Removed from stock!");

        // Map the product to the activity
        mapProductToActivity(productName, newActivity);

        updateProductQuantity();  // Update the Product Quantity

    }

    // This method updates the Product quantity
    public void updateProductQuantity() {
        String productName = getProductItem();
        String activityName = getActivityName();

        // Check if the name of the activity is equal to "Add to stock"
        if (activityName.equals("Add to stock")) {
            // Get the existing quantity from the activity
            int newProductQuantity = getQuantityActivity();

            // adding the activity quantity
            setProductQuantity(productName, newProductQuantity);

        } // Check if the name of the activity is equal to "Remove from stock"
        else if (activityName.equals("Remove from stock")) {
            // Get the existing quantity from the activity
            int newProductQuantity = getQuantityActivity();

            // removing the activity quantity
            setProductQuantity(productName, -newProductQuantity);
        } else {
            JOptionPane.showMessageDialog(this, "Activity quantity is not valid.");
        }
    }

    // This method is setting the quantity of the Product to the new quantity by taking the product name
    public void setProductQuantity(String productName, int productQuantity) {

        for (Product a : productList) {
            if (a.getProductName().equals(productName)) {
                a.updateQuantity(productQuantity);
                return; // Break out of the loop once the product is found and updated
            }
        }
        JOptionPane.showMessageDialog(this, "Product not found: " + productName);
    }

    // This method displays the activity information
    public void displayActivityInfo() {
        StringBuilder activityInfo = new StringBuilder();

        for (Activity a : activities) {
            activityInfo.append(a.displayActivity()).append("\n");
        }
        this.updateActivityInfoTextArea(activityInfo.toString());
    }

    // This method displays the Vendor report for product`s activity
    public void displayVendorReport() {
        String productName = getProductItem();
        // Retrieve the list of activities associated with the product
        List<Activity> activitiesList = productActivityList.get(productName);

        // Check if there are activities associated with the product
        if (activitiesList != null && !activitiesList.isEmpty()) {
            // If there are more than 4 activities, keep only the last 4
            if (activitiesList.size() > 4) {
                activitiesList.subList(0, activitiesList.size() - 4).clear();
            }

            StringBuilder report = new StringBuilder("Vendor Report for Product: " + productName + "\n");

            // Iterate through the activities and append their information
            for (Activity activity : activitiesList) {
                report.append(activity.displayActivity()).append("\n");
            }

            updateActivityInfoTextArea(report.toString());
        } else {
            JOptionPane.showMessageDialog(this, "No activity found for product: " + productName);
        }
    }

    // This method clears the information in the text fields so we can add another product
    public void clearProduct() {
        productIdTextF.setText("");
        productNameTextF.setText("");
        productDateTextF.setText("");
        productQuantityTextF.setText("");
        productTextArea.setText("");
        deleteTextF.setText("");
        categoryTextField.setText("");
    }

    // This method clears the information in the text fields so we can add another activity
    public void clearActivity() {
        activityIdTextF.setText("");
        activityDateTextF.setText("");
        activityQuantityTextF.setText("");
        activityTextArea.setText("");
    }
 
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MainPanel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        ProductPanel = new javax.swing.JPanel();
        productIdLabel = new javax.swing.JLabel();
        productIdTextF = new javax.swing.JTextField();
        ProductNamePanel = new javax.swing.JPanel();
        productNameLabel = new javax.swing.JLabel();
        productNameTextF = new javax.swing.JTextField();
        ProductCategoryPanel = new javax.swing.JPanel();
        categoryLabel = new javax.swing.JLabel();
        productCategoryBox = new javax.swing.JComboBox<>();
        ProductDatePanel = new javax.swing.JPanel();
        productDateLabel = new javax.swing.JLabel();
        productDateTextF = new javax.swing.JTextField();
        ProductQuantityPanel = new javax.swing.JPanel();
        productQuantityLabel = new javax.swing.JLabel();
        productQuantityTextF = new javax.swing.JTextField();
        addProductButton = new javax.swing.JButton();
        deleteProductButton = new javax.swing.JButton();
        displayProductButton = new javax.swing.JButton();
        addProductLabel = new javax.swing.JLabel();
        deleteProductLabel = new javax.swing.JLabel();
        displayProductLabel = new javax.swing.JLabel();
        deleteTextF = new javax.swing.JTextField();
        clearButton = new javax.swing.JButton();
        searchLabel = new javax.swing.JLabel();
        categoryTextField = new javax.swing.JTextField();
        displayByCategoryButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        ActivityPanel = new javax.swing.JPanel();
        activityIdLabel = new javax.swing.JLabel();
        activityIdTextF = new javax.swing.JTextField();
        ActivityNamePanel = new javax.swing.JPanel();
        activityNameLabel = new javax.swing.JLabel();
        activityBox = new javax.swing.JComboBox<>();
        ProductItemsPanel = new javax.swing.JPanel();
        itemsLabel = new javax.swing.JLabel();
        itemBox = new javax.swing.JComboBox<>();
        ActivityDatePanel = new javax.swing.JPanel();
        activityDateLabel = new javax.swing.JLabel();
        activityDateTextF = new javax.swing.JTextField();
        ActivityQuantityPanel = new javax.swing.JPanel();
        activityQuantityLabel = new javax.swing.JLabel();
        activityQuantityTextF = new javax.swing.JTextField();
        addStockButton = new javax.swing.JButton();
        removeStockButton = new javax.swing.JButton();
        displayStockButton = new javax.swing.JButton();
        addStockLabel = new javax.swing.JLabel();
        removeStockLabel = new javax.swing.JLabel();
        displayStockLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        clearButton2 = new javax.swing.JButton();
        vendorReportLabel = new javax.swing.JLabel();
        displayVendorButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        activityTextArea = new javax.swing.JTextArea();
        jScrollPane1 = new javax.swing.JScrollPane();
        productTextArea = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        MainPanel.setBackground(new java.awt.Color(153, 153, 153));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 2), "Product", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 14), new java.awt.Color(0, 102, 102))); // NOI18N
        jPanel1.setPreferredSize(new java.awt.Dimension(811, 314));

        ProductPanel.setBackground(new java.awt.Color(204, 204, 204));
        ProductPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51), 2), "Product ID", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Emoji", 3, 12), new java.awt.Color(0, 51, 51))); // NOI18N
        ProductPanel.setMinimumSize(new java.awt.Dimension(0, 0));
        ProductPanel.setPreferredSize(new java.awt.Dimension(233, 81));

        productIdLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        productIdLabel.setForeground(new java.awt.Color(0, 51, 51));
        productIdLabel.setText("ID: ");

        productIdTextF.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        productIdTextF.setMinimumSize(new java.awt.Dimension(93, 22));
        productIdTextF.setPreferredSize(new java.awt.Dimension(93, 22));

        javax.swing.GroupLayout ProductPanelLayout = new javax.swing.GroupLayout(ProductPanel);
        ProductPanel.setLayout(ProductPanelLayout);
        ProductPanelLayout.setHorizontalGroup(
            ProductPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProductPanelLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(productIdLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(productIdTextF, javax.swing.GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)
                .addContainerGap())
        );
        ProductPanelLayout.setVerticalGroup(
            ProductPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProductPanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(ProductPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(productIdLabel)
                    .addComponent(productIdTextF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        ProductNamePanel.setBackground(new java.awt.Color(204, 204, 204));
        ProductNamePanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51), 2), "Product Name", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Emoji", 3, 12), new java.awt.Color(0, 51, 51))); // NOI18N
        ProductNamePanel.setPreferredSize(new java.awt.Dimension(233, 81));

        productNameLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        productNameLabel.setForeground(new java.awt.Color(0, 51, 51));
        productNameLabel.setText("Name:");

        productNameTextF.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        productNameTextF.setMinimumSize(new java.awt.Dimension(93, 22));
        productNameTextF.setPreferredSize(new java.awt.Dimension(93, 22));

        javax.swing.GroupLayout ProductNamePanelLayout = new javax.swing.GroupLayout(ProductNamePanel);
        ProductNamePanel.setLayout(ProductNamePanelLayout);
        ProductNamePanelLayout.setHorizontalGroup(
            ProductNamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProductNamePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(productNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(productNameTextF, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
                .addContainerGap())
        );
        ProductNamePanelLayout.setVerticalGroup(
            ProductNamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProductNamePanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(ProductNamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(productNameLabel)
                    .addComponent(productNameTextF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        ProductCategoryPanel.setBackground(new java.awt.Color(204, 204, 204));
        ProductCategoryPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51), 2), "Product Category", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Emoji", 3, 12), new java.awt.Color(0, 51, 51))); // NOI18N
        ProductCategoryPanel.setPreferredSize(new java.awt.Dimension(233, 81));

        categoryLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        categoryLabel.setForeground(new java.awt.Color(0, 51, 51));
        categoryLabel.setText("Category:");

        productCategoryBox.setEditable(true);
        productCategoryBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Drinks", "Fruits", "Vegetables", "Diary", "Bakery" }));
        productCategoryBox.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        javax.swing.GroupLayout ProductCategoryPanelLayout = new javax.swing.GroupLayout(ProductCategoryPanel);
        ProductCategoryPanel.setLayout(ProductCategoryPanelLayout);
        ProductCategoryPanelLayout.setHorizontalGroup(
            ProductCategoryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProductCategoryPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(categoryLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(productCategoryBox, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );
        ProductCategoryPanelLayout.setVerticalGroup(
            ProductCategoryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProductCategoryPanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(ProductCategoryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(productCategoryBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(categoryLabel))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        ProductDatePanel.setBackground(new java.awt.Color(204, 204, 204));
        ProductDatePanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51), 2), "Product Date", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Emoji", 3, 12), new java.awt.Color(0, 51, 51))); // NOI18N

        productDateLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        productDateLabel.setForeground(new java.awt.Color(0, 51, 51));
        productDateLabel.setText("Date:");

        productDateTextF.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        productDateTextF.setPreferredSize(new java.awt.Dimension(93, 22));

        javax.swing.GroupLayout ProductDatePanelLayout = new javax.swing.GroupLayout(ProductDatePanel);
        ProductDatePanel.setLayout(ProductDatePanelLayout);
        ProductDatePanelLayout.setHorizontalGroup(
            ProductDatePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProductDatePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(productDateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(productDateTextF, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        ProductDatePanelLayout.setVerticalGroup(
            ProductDatePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProductDatePanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(ProductDatePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(productDateLabel)
                    .addComponent(productDateTextF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        ProductQuantityPanel.setBackground(new java.awt.Color(204, 204, 204));
        ProductQuantityPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51), 2), "Product Quantity", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Emoji", 3, 12), new java.awt.Color(0, 51, 51))); // NOI18N

        productQuantityLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        productQuantityLabel.setForeground(new java.awt.Color(0, 51, 51));
        productQuantityLabel.setText("Quantity:");

        productQuantityTextF.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        productQuantityTextF.setPreferredSize(new java.awt.Dimension(93, 22));

        javax.swing.GroupLayout ProductQuantityPanelLayout = new javax.swing.GroupLayout(ProductQuantityPanel);
        ProductQuantityPanel.setLayout(ProductQuantityPanelLayout);
        ProductQuantityPanelLayout.setHorizontalGroup(
            ProductQuantityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProductQuantityPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(productQuantityLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(productQuantityTextF, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        ProductQuantityPanelLayout.setVerticalGroup(
            ProductQuantityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProductQuantityPanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(ProductQuantityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(productQuantityLabel)
                    .addComponent(productQuantityTextF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        addProductButton.setText("add ");
        addProductButton.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        addProductButton.setFocusable(false);
        addProductButton.setMaximumSize(new java.awt.Dimension(39, 18));
        addProductButton.setMinimumSize(new java.awt.Dimension(39, 18));
        addProductButton.setPreferredSize(new java.awt.Dimension(26, 18));

        deleteProductButton.setText("delete ");
        deleteProductButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));
        deleteProductButton.setFocusable(false);
        deleteProductButton.setPreferredSize(new java.awt.Dimension(26, 18));

        displayProductButton.setText("display");
        displayProductButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));
        displayProductButton.setFocusable(false);
        displayProductButton.setPreferredSize(new java.awt.Dimension(26, 18));

        addProductLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        addProductLabel.setForeground(new java.awt.Color(0, 102, 102));
        addProductLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        addProductLabel.setText("Add product:");
        addProductLabel.setPreferredSize(new java.awt.Dimension(37, 16));

        deleteProductLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        deleteProductLabel.setForeground(new java.awt.Color(0, 102, 102));
        deleteProductLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        deleteProductLabel.setText("Delete product:");
        deleteProductLabel.setPreferredSize(new java.awt.Dimension(37, 16));

        displayProductLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        displayProductLabel.setForeground(new java.awt.Color(0, 102, 102));
        displayProductLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        displayProductLabel.setText("Display products:");
        displayProductLabel.setMaximumSize(new java.awt.Dimension(80, 16));
        displayProductLabel.setMinimumSize(new java.awt.Dimension(80, 16));
        displayProductLabel.setPreferredSize(new java.awt.Dimension(37, 16));

        deleteTextF.setToolTipText("enter product ID");
        deleteTextF.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        clearButton.setText("clear");
        clearButton.setToolTipText("");
        clearButton.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        clearButton.setFocusable(false);

        searchLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        searchLabel.setForeground(new java.awt.Color(0, 102, 102));
        searchLabel.setText("Search by category:");

        categoryTextField.setToolTipText("enter category");
        categoryTextField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        displayByCategoryButton.setText("display");
        displayByCategoryButton.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        displayByCategoryButton.setFocusable(false);

        jLabel2.setFont(new java.awt.Font("Segoe Print", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 102));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Clear the information");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(ProductPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)
                            .addComponent(ProductDatePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(ProductQuantityPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ProductNamePanel, javax.swing.GroupLayout.DEFAULT_SIZE, 239, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(78, 78, 78))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(clearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(69, 69, 69))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(ProductCategoryPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(addProductLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(displayProductLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(displayProductButton, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addProductButton, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(42, 42, 42)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(deleteProductLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchLabel, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(categoryTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteTextF, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(36, 36, 36)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(deleteProductButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(displayByCategoryButton, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ProductNamePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ProductPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ProductCategoryPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(ProductDatePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(ProductQuantityPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(clearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addProductLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addProductButton, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deleteProductLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deleteTextF, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deleteProductButton, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(displayByCategoryButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(searchLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(categoryTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(displayProductLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(displayProductButton, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(11, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 2), "Activity", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 14), new java.awt.Color(0, 102, 102))); // NOI18N
        jPanel2.setMinimumSize(new java.awt.Dimension(100, 100));

        ActivityPanel.setBackground(new java.awt.Color(204, 204, 204));
        ActivityPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51), 2), "Activity ID", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Emoji", 3, 12), new java.awt.Color(0, 51, 51))); // NOI18N

        activityIdLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        activityIdLabel.setForeground(new java.awt.Color(0, 51, 51));
        activityIdLabel.setText("ID: ");

        activityIdTextF.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        activityIdTextF.setMinimumSize(new java.awt.Dimension(93, 22));
        activityIdTextF.setPreferredSize(new java.awt.Dimension(93, 22));

        javax.swing.GroupLayout ActivityPanelLayout = new javax.swing.GroupLayout(ActivityPanel);
        ActivityPanel.setLayout(ActivityPanelLayout);
        ActivityPanelLayout.setHorizontalGroup(
            ActivityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ActivityPanelLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(activityIdLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(activityIdTextF, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        ActivityPanelLayout.setVerticalGroup(
            ActivityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ActivityPanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(ActivityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(activityIdLabel)
                    .addComponent(activityIdTextF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        ActivityNamePanel.setBackground(new java.awt.Color(204, 204, 204));
        ActivityNamePanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51), 2), "Activity Name", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Emoji", 3, 12), new java.awt.Color(0, 51, 51))); // NOI18N

        activityNameLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        activityNameLabel.setForeground(new java.awt.Color(0, 51, 51));
        activityNameLabel.setText("Name:");

        activityBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Add to stock", "Remove from stock" }));
        activityBox.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        activityBox.setPreferredSize(new java.awt.Dimension(93, 22));

        javax.swing.GroupLayout ActivityNamePanelLayout = new javax.swing.GroupLayout(ActivityNamePanel);
        ActivityNamePanel.setLayout(ActivityNamePanelLayout);
        ActivityNamePanelLayout.setHorizontalGroup(
            ActivityNamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ActivityNamePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(activityNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(activityBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        ActivityNamePanelLayout.setVerticalGroup(
            ActivityNamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ActivityNamePanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(ActivityNamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(activityNameLabel)
                    .addComponent(activityBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        ProductItemsPanel.setBackground(new java.awt.Color(204, 204, 204));
        ProductItemsPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51), 2), "Product Items", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Emoji", 3, 12), new java.awt.Color(0, 51, 51))); // NOI18N
        ProductItemsPanel.setPreferredSize(new java.awt.Dimension(233, 81));

        itemsLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        itemsLabel.setForeground(new java.awt.Color(0, 51, 51));
        itemsLabel.setText("Items:");

        itemBox.setSelectedItem(productNameTextF);
        itemBox.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        javax.swing.GroupLayout ProductItemsPanelLayout = new javax.swing.GroupLayout(ProductItemsPanel);
        ProductItemsPanel.setLayout(ProductItemsPanelLayout);
        ProductItemsPanelLayout.setHorizontalGroup(
            ProductItemsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProductItemsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(itemsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(itemBox, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        ProductItemsPanelLayout.setVerticalGroup(
            ProductItemsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProductItemsPanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(ProductItemsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(itemBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(itemsLabel))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        ActivityDatePanel.setBackground(new java.awt.Color(204, 204, 204));
        ActivityDatePanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51), 2), "Activity Date", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Emoji", 3, 12), new java.awt.Color(0, 51, 51))); // NOI18N

        activityDateLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        activityDateLabel.setForeground(new java.awt.Color(0, 51, 51));
        activityDateLabel.setText("Date:");

        activityDateTextF.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        activityDateTextF.setPreferredSize(new java.awt.Dimension(93, 22));

        javax.swing.GroupLayout ActivityDatePanelLayout = new javax.swing.GroupLayout(ActivityDatePanel);
        ActivityDatePanel.setLayout(ActivityDatePanelLayout);
        ActivityDatePanelLayout.setHorizontalGroup(
            ActivityDatePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ActivityDatePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(activityDateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(activityDateTextF, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        ActivityDatePanelLayout.setVerticalGroup(
            ActivityDatePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ActivityDatePanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(ActivityDatePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(activityDateLabel)
                    .addComponent(activityDateTextF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        ActivityQuantityPanel.setBackground(new java.awt.Color(204, 204, 204));
        ActivityQuantityPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51), 2), "Activity Quantity", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Emoji", 3, 12), new java.awt.Color(0, 51, 51))); // NOI18N

        activityQuantityLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        activityQuantityLabel.setForeground(new java.awt.Color(0, 51, 51));
        activityQuantityLabel.setText("Quantity:");

        activityQuantityTextF.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        activityQuantityTextF.setPreferredSize(new java.awt.Dimension(93, 22));

        javax.swing.GroupLayout ActivityQuantityPanelLayout = new javax.swing.GroupLayout(ActivityQuantityPanel);
        ActivityQuantityPanel.setLayout(ActivityQuantityPanelLayout);
        ActivityQuantityPanelLayout.setHorizontalGroup(
            ActivityQuantityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ActivityQuantityPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(activityQuantityLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(activityQuantityTextF, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        ActivityQuantityPanelLayout.setVerticalGroup(
            ActivityQuantityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ActivityQuantityPanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(ActivityQuantityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(activityQuantityLabel)
                    .addComponent(activityQuantityTextF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        addStockButton.setText("add ");
        addStockButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));
        addStockButton.setFocusable(false);
        addStockButton.setMaximumSize(new java.awt.Dimension(39, 18));
        addStockButton.setMinimumSize(new java.awt.Dimension(39, 18));

        removeStockButton.setText("remove");
        removeStockButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));
        removeStockButton.setFocusable(false);
        removeStockButton.setPreferredSize(new java.awt.Dimension(95, 23));

        displayStockButton.setText("display");
        displayStockButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));
        displayStockButton.setFocusable(false);
        displayStockButton.setPreferredSize(new java.awt.Dimension(95, 23));

        addStockLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        addStockLabel.setForeground(new java.awt.Color(0, 102, 102));
        addStockLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        addStockLabel.setText("Add to stock:");
        addStockLabel.setPreferredSize(new java.awt.Dimension(37, 16));

        removeStockLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        removeStockLabel.setForeground(new java.awt.Color(0, 102, 102));
        removeStockLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        removeStockLabel.setText("Remove from stock:");
        removeStockLabel.setPreferredSize(new java.awt.Dimension(37, 16));

        displayStockLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        displayStockLabel.setForeground(new java.awt.Color(0, 102, 102));
        displayStockLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        displayStockLabel.setText("Display activities:");
        displayStockLabel.setPreferredSize(new java.awt.Dimension(37, 16));

        jLabel1.setFont(new java.awt.Font("Segoe Print", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 102));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Clear the information");

        clearButton2.setText("clear");
        clearButton2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        clearButton2.setFocusable(false);

        vendorReportLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        vendorReportLabel.setForeground(new java.awt.Color(0, 102, 102));
        vendorReportLabel.setText("Vendor Report (choose from product items list) : ");

        displayVendorButton.setText("display");
        displayVendorButton.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        displayVendorButton.setFocusable(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(addStockLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(displayStockLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(displayStockButton, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                            .addComponent(addStockButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(47, 47, 47)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(vendorReportLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(removeStockLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(removeStockButton, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(displayVendorButton, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(46, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(ActivityDatePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ActivityPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ActivityQuantityPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ActivityNamePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(ProductItemsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(clearButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(70, 70, 70))))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(ActivityNamePanel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ActivityPanel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ProductItemsPanel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(clearButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(ActivityDatePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ActivityQuantityPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(removeStockLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(removeStockButton, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(addStockLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(addStockButton, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(displayStockLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(displayStockButton, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(vendorReportLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(displayVendorButton, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );

        activityTextArea.setEditable(false);
        activityTextArea.setColumns(5);
        activityTextArea.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        activityTextArea.setRows(20);
        activityTextArea.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102)));
        jScrollPane2.setViewportView(activityTextArea);

        productTextArea.setEditable(false);
        productTextArea.setColumns(5);
        productTextArea.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        productTextArea.setRows(20);
        productTextArea.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102)));
        jScrollPane1.setViewportView(productTextArea);

        javax.swing.GroupLayout MainPanelLayout = new javax.swing.GroupLayout(MainPanel);
        MainPanel.setLayout(MainPanelLayout);
        MainPanelLayout.setHorizontalGroup(
            MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MainPanelLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 820, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 263, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addGap(10, 10, 10))
        );
        MainPanelLayout.setVerticalGroup(
            MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MainPanelLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ActivityDatePanel;
    private javax.swing.JPanel ActivityNamePanel;
    private javax.swing.JPanel ActivityPanel;
    private javax.swing.JPanel ActivityQuantityPanel;
    private javax.swing.JPanel MainPanel;
    private javax.swing.JPanel ProductCategoryPanel;
    private javax.swing.JPanel ProductDatePanel;
    private javax.swing.JPanel ProductItemsPanel;
    private javax.swing.JPanel ProductNamePanel;
    private javax.swing.JPanel ProductPanel;
    private javax.swing.JPanel ProductQuantityPanel;
    private javax.swing.JComboBox<String> activityBox;
    private javax.swing.JLabel activityDateLabel;
    private javax.swing.JTextField activityDateTextF;
    private javax.swing.JLabel activityIdLabel;
    private javax.swing.JTextField activityIdTextF;
    private javax.swing.JLabel activityNameLabel;
    private javax.swing.JLabel activityQuantityLabel;
    private javax.swing.JTextField activityQuantityTextF;
    private javax.swing.JTextArea activityTextArea;
    public javax.swing.JButton addProductButton;
    private javax.swing.JLabel addProductLabel;
    public javax.swing.JButton addStockButton;
    private javax.swing.JLabel addStockLabel;
    private javax.swing.JLabel categoryLabel;
    private javax.swing.JTextField categoryTextField;
    public javax.swing.JButton clearButton;
    public javax.swing.JButton clearButton2;
    public javax.swing.JButton deleteProductButton;
    private javax.swing.JLabel deleteProductLabel;
    private javax.swing.JTextField deleteTextF;
    public javax.swing.JButton displayByCategoryButton;
    public javax.swing.JButton displayProductButton;
    private javax.swing.JLabel displayProductLabel;
    public javax.swing.JButton displayStockButton;
    private javax.swing.JLabel displayStockLabel;
    public javax.swing.JButton displayVendorButton;
    private javax.swing.JComboBox<String> itemBox;
    private javax.swing.JLabel itemsLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JComboBox<String> productCategoryBox;
    private javax.swing.JLabel productDateLabel;
    private javax.swing.JTextField productDateTextF;
    private javax.swing.JLabel productIdLabel;
    private javax.swing.JTextField productIdTextF;
    private javax.swing.JLabel productNameLabel;
    private javax.swing.JTextField productNameTextF;
    private javax.swing.JLabel productQuantityLabel;
    private javax.swing.JTextField productQuantityTextF;
    private javax.swing.JTextArea productTextArea;
    public javax.swing.JButton removeStockButton;
    private javax.swing.JLabel removeStockLabel;
    private javax.swing.JLabel searchLabel;
    private javax.swing.JLabel vendorReportLabel;
    // End of variables declaration//GEN-END:variables
}
