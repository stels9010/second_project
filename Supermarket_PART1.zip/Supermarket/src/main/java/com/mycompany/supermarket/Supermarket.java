package com.mycompany.supermarket;
import java.awt.event.ActionListener;

/**
 *
 * @author Stela Kostadinova, Student ID: 22042714
 */

// This class represents a Supermarket and implements the ActionListener interface
public abstract class Supermarket implements ActionListener {

    // The main method is the entry point for the program
    public static void main(String[] args) {
        MyFrame frame = new MyFrame();  // Create an instance of the MyFrame class
        frame.setResizable(false); // Set the frame to be non-resizable
        frame.setTitle("Supermarket"); // Set the title of the frame to "Supermarket"
        frame.setVisible(true);  // Make the frame visible

        // Set up an action listener for the addProductButton
        frame.addProductButton.addActionListener(event -> {
            // Create a new Product using information from the frame
            Product newProduct = new Product(frame.getIdProduct(), frame.getName(), frame.getCategory(), frame.getDateProduct(), frame.getQuantityProduct());
            frame.addProduct(newProduct);   // Add the new product
        });

        frame.displayProductButton.addActionListener(event -> {
            frame.displayProductInfo();  // Display product information 
        });

        frame.deleteProductButton.addActionListener(event -> {
            frame.deleteProduct(); // Delete a product 
        });

        frame.clearButton.addActionListener(event -> {
            frame.clearProduct(); // Clear product information 
        });

        frame.displayByCategoryButton.addActionListener(event -> {
            frame.displayByCategory(); // Display products by category 
        });

        frame.clearButton2.addActionListener(event -> {
            frame.clearActivity(); // Clear activity information 
        });

        frame.addStockButton.addActionListener(event -> {
            // Create a new Activity using information from the frame
            Activity newActivity = new Activity(frame.getIdActivity(), frame.getActivityName(), frame.getProductItem(), frame.getQuantityActivity(), frame.getDateActivity());
            frame.addToStock(newActivity); // Add the new activity to the stock
        });

        frame.removeStockButton.addActionListener(event -> {
            // Create a new Activity using information from the frame
            Activity newActivity = new Activity(frame.getIdActivity(), frame.getActivityName(), frame.getProductItem(), frame.getQuantityActivity(), frame.getDateActivity());
            frame.removeFromStock(newActivity); // Remove the activity from the stock
        });

        frame.displayStockButton.addActionListener(event -> {
            frame.displayActivityInfo(); // Display stock activity information 
        });

        frame.displayVendorButton.addActionListener(event -> {
            frame.displayVendorReport();  // Display vendor reports 
        });
    }
}
