package com.mycompany.supermarket;

/**
 *
 * @author Stela
 */


public class Product {

    private int productId;
    private String productName;
    private String category;
    private String productDate;
    private int productQuantity;

    public Product(int productId, String productName, String category, String productDate, int productQuantity) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
        this.productDate = productDate;
        this.productQuantity = productQuantity;
    }

    public void setProductId(int newProductID) {
        productId = newProductID;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductName(String newProductName) {
        productName = newProductName;
    }

    public String getProductName() {
        return productName;
    }

    public void setCategory(String newCategory) {
        category = newCategory;
    }

    public String getCategoryProduct() {
        return category;
    }

    public void setProductDate(String newProductDate) {
        productDate = newProductDate;
    }

    public String getProductDate() {
        return productDate;
    }

    public void setProductQuantity(int newQuantity) {
        productQuantity = newQuantity;
    }

    public int getProductQuantity() {
        return productQuantity;
    }

    public void updateQuantity(int quantity) {
        int Quantity = this.productQuantity + quantity;

        // Ensure the new quantity is non-negative
        if (Quantity >= 0) {
            this.productQuantity = Quantity;
        } else {
            // Handle the case where the updated quantity is not valid
            System.out.println("Invalid quantity update: Quantity cannot be negative.");
        }
    }

    public String displayProduct() {
        return "Product ID: " + productId + "\n"
                + "Name: " + productName + "\n"
                + "Category: " + category + "\n"
                + "Date: " + productDate + "\n"
                + "Quantity: " + productQuantity + "\n";
    }
}
